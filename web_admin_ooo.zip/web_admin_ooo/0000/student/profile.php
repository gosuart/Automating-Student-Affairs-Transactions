<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../config/database.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $student_id = $_GET['student_id'] ?? '';
        
        if (empty($student_id)) {
            echo json_encode([
                'success' => false,
                'message' => 'معرف الطالب مطلوب'
            ]);
            exit();
        }
        
        // جلب بيانات الطالب مع تفاصيل الكلية والقسم والمستوى
        $sql = "SELECT 
            s.id,
            s.student_id,
            s.name AS student_name,
            s.email,
            s.phone,
            s.academic_year,
            s.level,
            s.study_system,
            s.last_login,
            s.status,
            s.created_at AS student_created_at,
            c.name AS college_name,
            d.name AS department_name,
            l.level_code
        FROM students s
        LEFT JOIN colleges c ON s.college_id = c.id
        LEFT JOIN departments d ON s.department_id = d.id
        LEFT JOIN levels l ON s.level = l.id
        WHERE s.student_id = ?";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($student) {
            echo json_encode([
                'success' => true,
                'message' => 'تم جلب بيانات الملف الشخصي بنجاح',
                'data' => $student
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'لم يتم العثور على الطالب'
            ]);
        }
        
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'طريقة طلب غير مدعومة'
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في الخادم: ' . $e->getMessage()
    ]);
}
?>
