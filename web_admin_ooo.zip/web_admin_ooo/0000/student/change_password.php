<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../config/database.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // الحصول على البيانات من الطلب
        $input = json_decode(file_get_contents('php://input'), true);
        
        $student_id = $input['student_id'] ?? '';
        $old_password = $input['old_password'] ?? '';
        $new_password = $input['new_password'] ?? '';
        
        // التحقق من وجود جميع البيانات المطلوبة
        if (empty($student_id) || empty($old_password) || empty($new_password)) {
            echo json_encode([
                'success' => false,
                'message' => 'جميع الحقول مطلوبة'
            ]);
            exit();
        }
        
        // التحقق من طول كلمة المرور الجديدة
        if (strlen($new_password) < 6) {
            echo json_encode([
                'success' => false,
                'message' => 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل'
            ]);
            exit();
        }
        
        // جلب كلمة المرور الحالية للطالب
        $sql = "SELECT password FROM students WHERE student_id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$student) {
            echo json_encode([
                'success' => false,
                'message' => 'الطالب غير موجود'
            ]);
            exit();
        }
        
        // التحقق من كلمة المرور القديمة (بدون تشفير مؤقتاً)
        if ($old_password !== $student['password']) {
            echo json_encode([
                'success' => false,
                'message' => 'كلمة المرور القديمة غير صحيحة'
            ]);
            exit();
        }
        
        // حفظ كلمة المرور الجديدة (بدون تشفير مؤقتاً)
        $new_password_to_save = $new_password;
        
        // تحديث كلمة المرور في قاعدة البيانات
        $update_sql = "UPDATE students SET password = ?, updated_at = NOW() WHERE student_id = ?";
        $update_stmt = $db->prepare($update_sql);
        
        if ($update_stmt->execute([$new_password_to_save, $student_id])) {
            // التحقق من أن التحديث تم بنجاح
            if ($update_stmt->rowCount() > 0) {
                echo json_encode([
                    'success' => true,
                    'message' => 'تم تغيير كلمة المرور بنجاح! يرجى استخدام كلمة المرور الجديدة في تسجيل الدخول القادم.'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'لم يتم العثور على الطالب أو لم يتم تحديث كلمة المرور'
                ]);
            }
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'حدث خطأ أثناء تحديث كلمة المرور في قاعدة البيانات'
            ]);
        }
        
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'طريقة طلب غير مدعومة'
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في الخادم: ' . $e->getMessage()
    ]);
}
?>
